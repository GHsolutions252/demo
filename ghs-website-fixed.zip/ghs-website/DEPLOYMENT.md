# 🚀 Deployment Guide

## Fastest Method: Netlify Drop (2 Minutes)

### Step-by-Step:

1. **Open Netlify Drop**
   - Go to: [https://app.netlify.com/drop](https://app.netlify.com/drop)
   - No account needed!

2. **Drag Your Folder**
   - Drag the entire `ghs-website` folder onto the page
   - Wait 10-30 seconds for upload

3. **Your Site is LIVE! 🎉**
   - You'll get a URL like: `random-name-123456.netlify.app`
   - Click it to see your live website

4. **Optional: Customize (Free Account Required)**
   - Sign up for free at [netlify.com](https://netlify.com)
   - Claim your site
   - Change the URL to something like: `globalhornsolutions.netlify.app`
   - Add a custom domain (e.g., `globalhornsolutions.com`)

---

## Custom Domain Setup

### If You Own a Domain (e.g., globalhornsolutions.com)

**On Netlify:**

1. **Add Domain**
   - Go to Site Settings → Domain Management
   - Click "Add custom domain"
   - Enter your domain: `globalhornsolutions.com`

2. **Update DNS Records**
   
   **Option A: Netlify DNS (Recommended)**
   - Netlify gives you nameservers
   - Go to your domain registrar (GoDaddy, Namecheap, etc.)
   - Replace nameservers with Netlify's
   - Wait 24-48 hours for propagation
   
   **Option B: Keep Your DNS**
   - Add these records at your domain registrar:
   ```
   Type: A
   Name: @
   Value: 75.2.60.5
   
   Type: CNAME
   Name: www
   Value: your-site.netlify.app
   ```

3. **SSL Certificate**
   - Netlify automatically provisions free SSL
   - Your site will be `https://` within minutes

### Buying a Domain

**Recommended Registrars:**
- **Namecheap** - Good prices, easy to use
- **Google Domains** - Simple interface
- **Cloudflare** - Great for developers

**Domain Suggestions:**
- globalhornsolutions.com
- globalhorn.solutions
- ghsolutions.com
- berberatrade.com

---

## Alternative Deployment Methods

### Method 2: Vercel

**Why Vercel?**
- Fast global CDN
- Automatic HTTPS
- Great performance

**Steps:**
1. Install Vercel CLI:
   ```bash
   npm i -g vercel
   ```

2. Navigate to folder:
   ```bash
   cd ghs-website
   ```

3. Deploy:
   ```bash
   vercel
   ```

4. Follow prompts, your site goes live!

### Method 3: GitHub Pages

**Why GitHub Pages?**
- Free
- Integrated with Git
- Custom domain support

**Steps:**
1. Create GitHub account if needed
2. Create new repository: `globalhornsolutions-website`
3. Upload your files
4. Go to Settings → Pages
5. Select your branch as source
6. Site will be live at: `username.github.io/globalhornsolutions-website`

---

## Contact Form Setup

Your contact form currently shows a success message but doesn't send emails. Here's how to make it functional:

### Option 1: Netlify Forms (Easiest)

**Steps:**
1. In `app.js`, find the `<form>` tag in the ContactPage component
2. Add this attribute to the opening `<form>` tag:
   ```javascript
   data-netlify="true"
   ```
3. Redeploy your site
4. Form submissions appear in your Netlify dashboard
5. Set up email notifications in Netlify settings

### Option 2: Formspree (Free tier available)

**Steps:**
1. Sign up at [formspree.io](https://formspree.io)
2. Create a new form
3. Get your form endpoint (looks like: `https://formspree.io/f/xyzabc123`)
4. In `app.js`, update the `handleSubmit` function:
   ```javascript
   const handleSubmit = async (e) => {
     e.preventDefault();
     await fetch('https://formspree.io/f/YOUR_FORM_ID', {
       method: 'POST',
       headers: { 'Content-Type': 'application/json' },
       body: JSON.stringify(formData)
     });
     setSubmitted(true);
   };
   ```

### Option 3: EmailJS (No backend needed)

**Steps:**
1. Sign up at [emailjs.com](https://www.emailjs.com)
2. Create email service
3. Create email template
4. Install EmailJS: Add this to your `index.html` `<head>`:
   ```html
   <script src="https://cdn.jsdelivr.net/npm/@emailjs/browser@3/dist/email.min.js"></script>
   ```
5. Update form submission in `app.js` following EmailJS docs

---

## Performance Optimization

### After Deployment:

1. **Test Speed**
   - Go to [PageSpeed Insights](https://pagespeed.web.dev)
   - Enter your URL
   - Check mobile and desktop scores

2. **Optimize Logo**
   - Convert `logo.jpeg` to `logo.webp` for smaller file size
   - Use tools like [Squoosh](https://squoosh.app)

3. **Add Analytics** (Optional)
   - Google Analytics
   - Plausible (privacy-friendly)
   - Fathom

---

## Troubleshooting

### Site Not Loading?
- Clear browser cache (Ctrl+Shift+R or Cmd+Shift+R)
- Check if deployment finished
- Try incognito/private window

### Logo Not Showing?
- Verify `logo.jpeg` is in the same folder as `index.html`
- Check filename matches exactly (case-sensitive)

### Form Not Working?
- See "Contact Form Setup" section above
- Check browser console for errors (F12 → Console tab)

### Mobile Layout Issues?
- Site is fully responsive and tested
- Clear cache and try again

---

## What's Next?

### Immediate (Optional):
- ✅ Deploy to Netlify (2 minutes)
- ✅ Customize URL
- ✅ Set up contact form

### Short-term (Optional):
- 🌐 Connect custom domain
- 📧 Email notifications
- 📊 Add analytics

### Long-term (Optional):
- 📝 Blog section
- 🌍 Multi-language support
- 👥 Client testimonials
- 📸 Photo gallery
- 🎬 Video content

---

## Need Help?

**Netlify Support:**
- Docs: [docs.netlify.com](https://docs.netlify.com)
- Community: [answers.netlify.com](https://answers.netlify.com)

**General Web Help:**
- MDN Web Docs: [developer.mozilla.org](https://developer.mozilla.org)
- Stack Overflow: [stackoverflow.com](https://stackoverflow.com)

---

**Your website is ready to launch! 🚀**

Start with Netlify Drop - it's the fastest way to get online.
