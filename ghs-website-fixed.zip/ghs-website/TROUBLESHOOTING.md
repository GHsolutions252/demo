# Troubleshooting Guide - Blank Page Issue

## Common Causes & Solutions

### Issue: Blank page on Netlify

This is usually caused by one of these issues:

### **Solution 1: Check Browser Console**
1. Open the live Netlify site
2. Press **F12** or right-click → Inspect
3. Go to the **Console** tab
4. Look for any red error messages
5. Share the error with me if you see one

### **Solution 2: File Structure**
Make sure when you drag to Netlify, you're dragging the **folder contents**, not a nested folder.

**CORRECT structure:**
```
ghs-website/
├── index.html
├── app.js
├── logo.jpeg
├── README.md
└── DEPLOYMENT.md
```

**WRONG (causes blank page):**
```
some-folder/
└── ghs-website/
    ├── index.html
    ├── app.js
    └── ...
```

### **Solution 3: Try Local First**
1. Extract the ZIP
2. Double-click `index.html`
3. Does it work in your browser?
   - If YES: The issue is with how you're uploading to Netlify
   - If NO: There might be a file issue

### **Solution 4: Manual Netlify Upload**
Instead of drag-and-drop, try:
1. Go to https://app.netlify.com (sign up if needed)
2. Click "Add new site" → "Deploy manually"
3. Drag the **ghs-website folder** (or just the files inside it)
4. Wait for deployment

### **Solution 5: Check All Files Uploaded**
In Netlify, after uploading:
1. Click on your site
2. Go to "Deploys" tab
3. Click on the latest deploy
4. Look for "Deploy log" or "Browse deploy"
5. Verify ALL these files are there:
   - index.html
   - app.js
   - logo.jpeg

### **Most Common Fix:**
You might be dragging a folder containing a folder. 

**Do this:**
1. Extract `ghs-website-enhanced.zip`
2. Open the `ghs-website` folder
3. Select **ALL the files inside** (index.html, app.js, logo.jpeg, etc.)
4. Drag those files (not the folder) to Netlify

---

## Quick Test

Open `index.html` on your computer by double-clicking it.

**Does it work locally?**
- ✅ YES → Problem is with Netlify upload
- ❌ NO → Try the fixed version I'm creating below

Let me know which one it is!
